# OS Types
#OS_WINDOWS = "Windows"
#OS_LINUX = "Linux"

# script name
BURN_CPU = "cpu_stress_test"
BURN_IO = "burn_io"
FILL_DISK = "fill_disk"
NETWORK_UTIL = "network_advanced"
KILLALL_PROCESSES = "killall_processes"
KILL_PROCESS = "kill_process"
SHELL = "shell"
